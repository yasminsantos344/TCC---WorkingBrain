import { ActivityIndicator } from "react-native";

export function Loading(){
    return(
        <ActivityIndicator size={"large"} color={'#000'} />
    )
}